Part 1, Matrix differentiation:
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/ml-mipt/ml-mipt/blob/basic_s20/homeworks_basic/Lab1_ML_pipeline_and_SVM/Lab1_part1_differentiation.ipynb)

Part 2, Data preprocessing and ML pipeline:
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/ml-mipt/ml-mipt/blob/basic_s20/homeworks_basic/Lab1_ML_pipeline_and_SVM/Lab1_part2_ml_pipeline.ipynb)

Part 3, SVM:
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/ml-mipt/ml-mipt/blob/basic_s20/homeworks_basic/Lab1_ML_pipeline_and_SVM/Lab1_part3_SVM.ipynb)
